# Lead Bot - Бот для сбора заявок

## Описание

Telegram бот для сбора заявок от пользователей с полной интеграцией в Django админку.

## Возможности

✅ Полноценное управление через Django админку  
✅ Conversation handler для пошагового сбора данных  
✅ Валидация телефона (+380 формат)  
✅ Опциональный email и комментарий  
✅ Отправка уведомлений на email  
✅ Отправка уведомлений в Telegram администратору  
✅ Контроль доступа через Django permissions  
✅ Гибкая настройка текстов через админку  

## Установка

### 1. Добавить приложение в INSTALLED_APPS

```python
# profiling/settings.py

INSTALLED_APPS = [
    # ...
    'leads',  # <-- добавить
]
```

### 2. Настроить EMAIL в settings.py

```python
# profiling/settings.py

# Email настройки (пример для Gmail)
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER
```

### 3. Создать миграции и применить

```bash
python manage.py makemigrations leads
python manage.py migrate leads
```

### 4. Создать permissions для пользователей

```python
# В Django shell или через админку
from django.contrib.auth.models import User, Permission
from django.contrib.contenttypes.models import ContentType
from leads.models import Lead

# Получить нужные permissions
view_leads = Permission.objects.get(codename='can_view_leads')
manage_bot = Permission.objects.get(codename='can_manage_lead_bot')

# Назначить пользователю
user = User.objects.get(username='manager')
user.user_permissions.add(view_leads)
```

### 5. Настроить бот в админке

1. Зайти в админку Django
2. Перейти в раздел **Bots** → добавить нового бота
3. Перейти в раздел **Настройки Lead Bot** → создать конфигурацию:
   - Выбрать бота
   - Указать `notification_email` (куда слать заявки)
   - Указать `admin_user_id` (Telegram ID админа)
   - Настроить тексты бота (опционально)

### 6. Интегрировать в bot_runner_aiogram.py

Найти в файле `bot_runner_aiogram.py` функцию где регистрируются handlers и добавить:

```python
# bot_runner_aiogram.py
# ...

# Импорт в начале файла
from leads.bot import register_handlers as register_lead_handlers

# В функции run_webhook или run_longpoll после создания Dispatcher:
async def run_webhook(bot_model: BotModel):
    dp = Dispatcher()
    pool = await make_pool()
    session = aiohttp.ClientSession()
    
    # Регистрация handlers подписок (уже есть)
    register_subs(dp, pool=pool, session=session, bot_model=bot_model)
    
    # ДОБАВИТЬ: Регистрация handlers заявок
    register_lead_handlers(dp, bot_id=bot_model.bot_id)
    
    # ... остальной код
```

### 7. Запустить бота

```bash
python bot_runner_aiogram.py --bot-id <BOT_ID>
```

## Структура приложения

```
leads/
├── __init__.py
├── apps.py
├── models.py              # Модели LeadBotConfig и Lead
├── admin.py               # Админка с правами доступа
├── migrations/
│   └── __init__.py
└── bot/
    ├── __init__.py
    ├── states.py          # FSM состояния
    ├── keyboards.py       # Клавиатуры
    ├── handlers.py        # Conversation handlers
    └── utils.py           # Утилиты (валидация, уведомления)
```

## Модели

### LeadBotConfig

Настройки бота:
- `bot` - связь с Bot из core
- `notification_email` - email для уведомлений
- `admin_user_id` - Telegram ID администратора
- `welcome_text`, `phone_request_text`, etc. - настройка текстов

### Lead

Заявка пользователя:
- `bot` - связь с Bot
- `user` - связь с TelegramUser
- `full_name` - имя пользователя
- `phone` - телефон (валидируется)
- `email` - email (опционально)
- `comment` - комментарий (опционально)
- `status` - статус заявки (new, in_progress, completed, cancelled)
- `email_sent`, `telegram_sent` - флаги отправки уведомлений

## Permissions

Приложение использует кастомные permissions:

- `leads.can_view_leads` - просмотр заявок
- `leads.can_manage_lead_bot` - управление настройками бота

Назначайте эти права пользователям/группам через Django админку.

## Логика работы бота

1. `/start` → Приветствие, запрос имени
2. Ввод имени → Запрос телефона (можно отправить контакт)
3. Ввод/отправка телефона → Валидация, подтверждение
4. Подтверждение телефона → Вопрос о комментарии
5. Ответ на вопрос:
   - **Да** → Ввод комментария → Финальное подтверждение
   - **Нет** → Финальное подтверждение
6. Финальное подтверждение:
   - **Подтвердить** → Сохранение в БД + уведомления
   - **Исправить** → Начать заново

## Валидация

- **Телефон**: `+380XXXXXXXXX` (автоматическая нормализация из `380...` или `0...`)
- **Email**: стандартная email валидация Django
- **Имя**: минимум 2 символа

## Уведомления

При успешном сохранении заявки:
1. Отправляется email на `notification_email` (если указан)
2. Отправляется сообщение в Telegram на `admin_user_id` (если указан)

## Безопасность

- Проверка `is_blocked` перед обработкой команд
- Контроль доступа к админке через permissions
- Логирование всех действий
- Обработка ошибок без раскрытия внутренней информации

## Расширение

Для добавления дополнительных полей в заявку:

1. Добавить поле в модель `Lead`
2. Добавить состояние в `LeadForm`
3. Добавить handler в `handlers.py`
4. Обновить `format_lead_summary` в `utils.py`
5. Создать миграцию и применить

## Тестирование

Рекомендуется создать тесты по аналогии с существующими:

```python
# tests/leads/test_lead_handlers.py
import pytest
from leads.bot.handlers import cmd_start

# Тесты...
```

## Логи

Все действия логируются с префиксом `leads.bot`:

```python
logger = logging.getLogger("leads.bot")
```

Настройка логирования в `settings.py`:

```python
LOGGING = {
    # ...
    'loggers': {
        'leads.bot': {
            'handlers': ['file'],
            'level': 'INFO',
            'propagate': False,
        },
    }
}
```

## Поддержка

При возникновении вопросов или проблем:
1. Проверьте логи бота
2. Проверьте настройки в админке
3. Убедитесь что permissions назначены корректно
4. Проверьте EMAIL настройки

---

**Автор**: Claude  
**Дата**: 2025
