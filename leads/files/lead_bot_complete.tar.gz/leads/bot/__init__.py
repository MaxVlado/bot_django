# leads/bot/__init__.py
from .handlers import register_handlers

__all__ = ['register_handlers']
