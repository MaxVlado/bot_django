# 📂 ОПИСАНИЕ ФАЙЛОВ LEAD BOT

## Структура приложения

```
leads/
│
├── 📄 __init__.py                    # Инициализация приложения
├── 📄 apps.py                        # Конфигурация Django приложения
├── 📄 models.py                      # Модели: LeadBotConfig, Lead
├── 📄 admin.py                       # Админка с фильтрами и правами
│
├── 📄 README.md                      # Полная документация
├── 📄 setup_commands.py              # Команды для быстрой настройки
├── 📄 integration_example.py         # Пример интеграции в bot_runner
│
├── 📁 migrations/                    # Миграции БД
│   └── __init__.py
│
└── 📁 bot/                           # Модуль бота
    ├── __init__.py                   # Экспорт register_handlers
    ├── states.py                     # FSM состояния (LeadForm)
    ├── keyboards.py                  # Telegram клавиатуры
    ├── handlers.py                   # Conversation handlers
    └── utils.py                      # Утилиты (валидация, уведомления)
```

---

## 📄 Подробное описание файлов

### Корневые файлы

#### `__init__.py`
- Инициализация Django приложения
- Указывает на `LeadsConfig` из `apps.py`

#### `apps.py`
- Конфигурация приложения для Django
- Устанавливает `verbose_name = '📋 Заявки (Lead Bot)'`
- Определяет `default_auto_field = 'BigAutoField'`

#### `models.py` ⭐ **ВАЖНО**
**Модели данных:**

1. **LeadBotConfig** - настройки бота
   - `bot` - OneToOne связь с Bot из core
   - `notification_email` - email для уведомлений
   - `admin_user_id` - Telegram ID администратора
   - `welcome_text`, `phone_request_text`, etc. - тексты бота
   - **Permissions**:
     - `can_view_leads` - просмотр заявок
     - `can_manage_lead_bot` - управление настройками

2. **Lead** - заявка пользователя
   - `bot` - связь с Bot
   - `user` - связь с TelegramUser
   - `full_name` - имя (обязательно)
   - `phone` - телефон +380XXXXXXXXX (валидируется)
   - `email` - email (опционально)
   - `comment` - комментарий (опционально)
   - `status` - статус: new, in_progress, completed, cancelled
   - `email_sent`, `telegram_sent` - флаги отправки уведомлений

#### `admin.py` ⭐ **ВАЖНО**
**Админка с контролем доступа:**

1. **LeadBotConfigAdmin**
   - Настройка конфигурации бота
   - Контроль через `can_manage_lead_bot`
   - Только суперпользователи могут удалять

2. **LeadAdmin**
   - Просмотр и управление заявками
   - Фильтры: статус, уведомления, бот, дата
   - Цветные метки статусов
   - Иконки уведомлений (📧/✅)
   - Контроль через `can_view_leads`
   - Создание заявок только через бота
   - Select_related оптимизация

#### `README.md`
- Полная документация проекта
- Описание возможностей
- Инструкции по установке
- Руководство по расширению
- Информация о безопасности и тестировании

#### `setup_commands.py`
- Готовые команды для Django shell
- Создание группы "Lead Managers"
- Назначение прав
- Примеры конфигурации
- Информация о текущих настройках

#### `integration_example.py`
- Пример интеграции в `bot_runner_aiogram.py`
- Показывает где добавить импорт
- Показывает где зарегистрировать handlers
- Полные примеры функций
- Checklist для проверки

---

### Модуль bot/

#### `bot/__init__.py`
- Экспортирует `register_handlers` для удобного импорта
- `from leads.bot import register_handlers`

#### `bot/states.py` ⭐ **ВАЖНО**
**FSM состояния conversation:**

```python
class LeadForm(StatesGroup):
    waiting_for_name          # Ожидание имени
    waiting_for_phone         # Ожидание телефона
    validating_phone          # Валидация телефона
    waiting_for_email         # Ожидание email
    asking_for_comment        # Вопрос о комментарии
    waiting_for_comment       # Ожидание комментария
    confirming_data           # Подтверждение данных
```

#### `bot/keyboards.py` ⭐ **ВАЖНО**
**Telegram клавиатуры:**

1. `get_phone_keyboard()` - ReplyKeyboard с кнопкой "Поділитися номером"
2. `get_phone_validation_keyboard()` - Inline: "Так, все вірно" / "Виправити"
3. `get_comment_question_keyboard()` - Inline: "Так" / "Ні"
4. `get_confirmation_keyboard()` - Inline: "Так, все вірно" / "Виправити"
5. `get_question_keyboard()` - Inline: "Є питання"

#### `bot/handlers.py` ⭐ **КЛЮЧЕВОЙ ФАЙЛ**
**Основная логика бота:**

**Утилиты:**
- `get_or_create_user()` - создание/обновление пользователя
- `get_bot_config()` - получение конфигурации бота

**Handlers:**
1. `cmd_start()` - /start: начало conversation
2. `cmd_cancel()` - /cancel: отмена операции
3. `process_name()` - обработка имени
4. `process_contact()` - обработка контакта с телефоном
5. `process_phone_text()` - обработка телефона текстом
6. `phone_confirmed()` - подтверждение телефона
7. `phone_edit()` - редактирование телефона
8. `comment_yes()` - пользователь хочет комментарий
9. `comment_no()` - пользователь не хочет комментарий
10. `process_comment()` - обработка комментария
11. `confirm_and_save()` - финальное сохранение + уведомления
12. `confirm_edit()` - начать заново
13. `new_question()` - кнопка "Є питання"
14. `register_handlers()` - регистрация в dispatcher

**Особенности:**
- Использует FSM для управления состояниями
- Валидация на каждом шаге
- Асинхронная работа с БД через `sync_to_async`
- Отправка уведомлений после сохранения
- Логирование всех действий
- Обработка ошибок

#### `bot/utils.py` ⭐ **ВАЖНО**
**Утилиты и валидация:**

**Функции валидации:**
1. `validate_phone()` - валидация и нормализация телефона
   - Поддерживает: +380XXXXXXXXX, 380XXXXXXXXX, 0XXXXXXXXX
   - Возвращает: (is_valid, normalized_phone)

2. `validate_email()` - простая валидация email
   - Regex проверка формата

**Функции уведомлений:**
3. `send_email_notification()` - отправка email
   - Использует Django send_mail
   - Форматирует сообщение с данными заявки
   - Логирует результат
   - Возвращает: True/False

4. `send_telegram_notification()` - отправка в Telegram админу
   - Форматирует HTML сообщение
   - Использует aiogram Bot.send_message
   - Обрабатывает TelegramAPIError
   - Логирует результат
   - Возвращает: True/False

**Функции форматирования:**
5. `format_lead_summary()` - форматирование сводки данных
   - Используется для показа пользователю перед сохранением
   - HTML разметка

---

## 🔗 Взаимосвязи файлов

```
models.py
    ↓ используется в
admin.py  ←→  handlers.py
    ↓              ↓
    ↓         states.py
    ↓         keyboards.py
    ↓         utils.py
    ↓              ↓
    └──────────────┴─→ bot_runner_aiogram.py
```

---

## 📊 Статистика

- **Всего файлов**: 13
- **Python модулей**: 10
- **Документация**: 3
- **Строк кода**: ~1500+
- **Классов**: 4 (2 модели, 2 админки)
- **Функций**: ~20+
- **Handlers**: 13

---

## 🔑 Ключевые файлы для изменения

Если нужно изменить:

1. **Поля заявки** → `models.py` (Lead)
2. **Тексты бота** → админка (LeadBotConfig) или `models.py` (defaults)
3. **Логику диалога** → `bot/handlers.py`
4. **Клавиатуры** → `bot/keyboards.py`
5. **Валидацию** → `bot/utils.py` (validate_*)
6. **Уведомления** → `bot/utils.py` (send_*)
7. **Админку** → `admin.py`
8. **Права доступа** → `models.py` (Meta.permissions) + `admin.py`

---

## 📦 Зависимости

**Django:**
- `django.db.models`
- `django.contrib.admin`
- `django.core.mail`
- `django.core.validators`

**Aiogram:**
- `aiogram` (Router, types, filters, FSM)
- `aiogram.exceptions` (TelegramAPIError)

**Другие:**
- `asgiref.sync` (sync_to_async)
- `re` (regex валидация)
- `logging`

**Внутренние:**
- `core.models` (TelegramUser, Bot)

---

## ✅ Checklist файлов при установке

- [ ] Скопировать всю папку `leads/` в проект
- [ ] Добавить `'leads'` в `INSTALLED_APPS`
- [ ] Настроить EMAIL в settings.py
- [ ] Запустить `makemigrations` и `migrate`
- [ ] Создать группу и права (setup_commands.py)
- [ ] Добавить импорт в bot_runner_aiogram.py
- [ ] Добавить регистрацию handlers в bot_runner_aiogram.py
- [ ] Настроить LeadBotConfig в админке
- [ ] Запустить бота
- [ ] Протестировать /start

---

**Все файлы готовы к использованию!**
