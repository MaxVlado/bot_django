# ⚡ БЫСТРЫЙ СТАРТ LEAD BOT

## 📋 Чеклист установки (5-10 минут)

### ✅ Шаг 1: Копирование файлов (30 сек)
```bash
# Скопируйте папку leads/ в корень проекта
cp -r leads/ /path/to/your/project/
```

Структура должна быть:
```
your_project/
├── core/
├── subscriptions/
├── payments/
├── leads/          # ← новая папка
├── profiling/
└── manage.py
```

---

### ✅ Шаг 2: Добавить в settings.py (1 мин)

**В `INSTALLED_APPS` добавить:**
```python
INSTALLED_APPS = [
    # ...
    'leads',  # ← ДОБАВИТЬ
]
```

**Настроить EMAIL (если еще нет):**
```python
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER
```

**В .env добавить:**
```env
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
```

---

### ✅ Шаг 3: Миграции (30 сек)
```bash
python manage.py makemigrations leads
python manage.py migrate leads
```

---

### ✅ Шаг 4: Права доступа (1 мин)
```bash
python manage.py shell < leads/setup_commands.py
```

Или вручную в shell:
```python
from django.contrib.auth.models import Group, Permission

group, _ = Group.objects.get_or_create(name='Lead Managers')
perms = Permission.objects.filter(codename__in=['can_view_leads', 'can_manage_lead_bot'])
group.permissions.set(perms)
```

**Добавить пользователя в группу:**
- Через админку: Users → ваш пользователь → Groups → "Lead Managers"
- Или в shell:
  ```python
  from django.contrib.auth.models import User, Group
  User.objects.get(username='manager').groups.add(Group.objects.get(name='Lead Managers'))
  ```

---

### ✅ Шаг 5: Настройка бота в админке (2 мин)

1. Зайти в Django админку
2. **Настройки Lead Bot** → Add
3. Заполнить:
   - Бот: выбрать
   - Notification email: `admin@example.com`
   - Admin user id: `123456789` (узнать через @userinfobot)
4. Save

---

### ✅ Шаг 6: Интеграция в bot_runner_aiogram.py (2 мин)

**В начале файла добавить:**
```python
from leads.bot import register_handlers as register_lead_handlers
```

**В функциях `run_webhook` и `run_longpoll` добавить:**
```python
# После register_subs(...) добавить:
register_lead_handlers(dp, bot_id=bot_model.bot_id)
```

**Пример:**
```python
async def run_webhook(bot_model: BotModel):
    dp = Dispatcher()
    pool = await make_pool()
    session = aiohttp.ClientSession()
    
    register_subs(dp, pool=pool, session=session, bot_model=bot_model)
    register_lead_handlers(dp, bot_id=bot_model.bot_id)  # ← ДОБАВИТЬ
    
    # ... остальной код
```

---

### ✅ Шаг 7: Запуск и тест (1 мин)

```bash
# Запустить бота
python bot_runner_aiogram.py --bot-id <YOUR_BOT_ID>

# Или в dev режиме
python bot_runner_aiogram.py --bot-id <YOUR_BOT_ID> --dev
```

**Проверка:**
1. Открыть бота в Telegram
2. Отправить `/start`
3. Ожидается: приветственное сообщение с запросом имени
4. Пройти весь процесс
5. Проверить в админке: **Заявки** → новая заявка
6. Проверить email и Telegram уведомления

---

## 🚨 Быстрые решения проблем

### Бот не отвечает
```bash
# Проверить запущен ли
ps aux | grep bot_runner

# Проверить логи
tail -f botlogs/bot_*.log

# Проверить импорт в bot_runner_aiogram.py
grep "register_lead_handlers" bot_runner_aiogram.py
```

### Email не приходит
```bash
# Тест отправки
python manage.py shell
>>> from django.core.mail import send_mail
>>> send_mail('Test', 'Test', 'from@example.com', ['to@example.com'])
```

### Пользователь не видит админку
```python
# В Django shell
from django.contrib.auth.models import User, Group
user = User.objects.get(username='manager')
group = Group.objects.get(name='Lead Managers')
user.groups.add(group)
# или
user.is_staff = True
user.save()
```

---

## 📝 Что дальше?

После успешной установки:
- ✅ Бот работает и собирает заявки
- ✅ Заявки сохраняются в БД
- ✅ Уведомления приходят
- ✅ Админка настроена

**Кастомизация:**
- Тексты бота → Админка → Настройки Lead Bot → Тексты бота
- Поля заявки → `leads/models.py` → модель Lead
- Логика диалога → `leads/bot/handlers.py`

**Документация:**
- 📖 `INSTALLATION.md` - полная инструкция
- 📂 `FILES_DESCRIPTION.md` - описание файлов
- 📚 `leads/README.md` - документация приложения
- 🔧 `leads/integration_example.py` - примеры интеграции

---

## ⏱️ Время установки: 5-10 минут

**Готово! 🎉**
