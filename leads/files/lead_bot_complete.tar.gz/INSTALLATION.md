# 📋 УСТАНОВКА И НАСТРОЙКА LEAD BOT

## ✅ Что уже сделано

Создано полнофункциональное Django приложение `leads` для сбора заявок через Telegram бота:

- ✅ Модели: `LeadBotConfig`, `Lead`
- ✅ Админка с фильтрами и контролем доступа
- ✅ FSM Conversation Handler
- ✅ Валидация данных (телефон, email)
- ✅ Отправка уведомлений (email + Telegram)
- ✅ Кастомные permissions для контроля доступа

## 📁 Структура файлов

```
leads/
├── __init__.py
├── apps.py
├── models.py              # Модели
├── admin.py               # Админка
├── README.md              # Документация
├── setup_commands.py      # Команды для настройки
├── integration_example.py # Пример интеграции
├── migrations/
│   └── __init__.py
└── bot/
    ├── __init__.py
    ├── states.py          # FSM состояния
    ├── keyboards.py       # Клавиатуры
    ├── handlers.py        # Conversation handlers
    └── utils.py           # Утилиты
```

---

## 🚀 ПОШАГОВАЯ УСТАНОВКА

### Шаг 1: Копирование файлов

Скопируйте папку `leads/` в корень вашего Django проекта (рядом с `core/`, `subscriptions/`, etc.)

```bash
# Структура должна выглядеть так:
your_project/
├── core/
├── subscriptions/
├── payments/
├── leads/          # <-- новая папка
├── profiling/
└── manage.py
```

### Шаг 2: Добавление в INSTALLED_APPS

Откройте `profiling/settings.py` и добавьте `'leads'` в `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    
    # Local apps
    'core',
    'subscriptions',
    'payments',
    'botops',
    'leads',  # ✅ ДОБАВИТЬ ЭТУ СТРОКУ
]
```

### Шаг 3: Настройка EMAIL

В `profiling/settings.py` добавьте настройки email (если еще нет):

```python
# Email Configuration
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'smtp.gmail.com')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', '587'))
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER
```

Добавьте в `.env`:

```env
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
```

**Важно для Gmail:**
- Используйте App Password, не обычный пароль
- Инструкция: https://support.google.com/accounts/answer/185833

### Шаг 4: Создание миграций

```bash
python manage.py makemigrations leads
python manage.py migrate leads
```

### Шаг 5: Создание группы и прав

Запустите в Django shell:

```bash
python manage.py shell
```

Затем выполните:

```python
from django.contrib.auth.models import Group, Permission

# Создать группу
group, _ = Group.objects.get_or_create(name='Lead Managers')

# Добавить права
perms = Permission.objects.filter(codename__in=['can_view_leads', 'can_manage_lead_bot'])
group.permissions.set(perms)

print("✅ Группа 'Lead Managers' создана с правами")
```

Или используйте готовый скрипт:

```bash
python manage.py shell < leads/setup_commands.py
```

### Шаг 6: Добавление пользователей в группу

Через Django shell:

```python
from django.contrib.auth.models import User, Group

user = User.objects.get(username='your_manager')
group = Group.objects.get(name='Lead Managers')
user.groups.add(group)

print(f"✅ Пользователь {user.username} добавлен в группу")
```

Или через админку:
1. Users → выберите пользователя
2. Groups → добавьте "Lead Managers"
3. Save

### Шаг 7: Настройка бота в админке

1. Зайдите в Django админку
2. Перейдите в **Настройки Lead Bot**
3. Нажмите **Добавить**
4. Заполните:
   - **Бот**: выберите бота из списка
   - **Notification email**: email для уведомлений о заявках
   - **Admin user id**: ваш Telegram user_id (узнать: @userinfobot)
5. Опционально настройте тексты бота
6. Сохраните

### Шаг 8: Интеграция в bot_runner_aiogram.py

Откройте `bot_runner_aiogram.py` и внесите изменения:

**В начале файла добавьте импорт:**

```python
from leads.bot import register_handlers as register_lead_handlers
```

**В функции `run_webhook` добавьте регистрацию:**

```python
async def run_webhook(bot_model: BotModel):
    dp = Dispatcher()
    pool = await make_pool()
    session = aiohttp.ClientSession()
    
    # Существующие handlers
    register_subs(dp, pool=pool, session=session, bot_model=bot_model)
    
    # ✅ ДОБАВИТЬ ЭТУ СТРОКУ:
    register_lead_handlers(dp, bot_id=bot_model.bot_id)
    
    # ... остальной код без изменений
```

**Аналогично в функции `run_longpoll`:**

```python
async def run_longpoll(bot_model: BotModel):
    dp = Dispatcher()
    pool = await make_pool()
    session = aiohttp.ClientSession()
    
    register_subs(dp, pool=pool, session=session, bot_model=bot_model)
    
    # ✅ ДОБАВИТЬ ЭТУ СТРОКУ:
    register_lead_handlers(dp, bot_id=bot_model.bot_id)
    
    # ... остальной код без изменений
```

### Шаг 9: Запуск бота

```bash
python bot_runner_aiogram.py --bot-id <YOUR_BOT_ID>
```

Или в dev режиме:

```bash
python bot_runner_aiogram.py --bot-id <YOUR_BOT_ID> --dev
```

---

## 🧪 ПРОВЕРКА РАБОТЫ

### 1. Проверка в Telegram

1. Откройте бота в Telegram
2. Отправьте `/start`
3. Ожидаемый ответ: приветственное сообщение с запросом имени
4. Пройдите весь процесс:
   - Введите имя
   - Введите телефон (или отправьте контакт)
   - Подтвердите телефон
   - Ответьте на вопрос о комментарии
   - Подтвердите данные
5. Ожидаемый результат: сообщение об успешной отправке

### 2. Проверка в админке

1. Откройте Django админку
2. Перейдите в **Заявки**
3. Должна появиться новая заявка со всеми данными
4. Проверьте статусы уведомлений (📧 и ✅ иконки)

### 3. Проверка уведомлений

- **Email**: проверьте указанный email
- **Telegram**: проверьте сообщения администратору

### 4. Проверка логов

```bash
# Если логи в файл
tail -f botlogs/bot_<bot_id>.log | grep "leads.bot"
```

Ожидаемые логи:
```
INFO leads.bot: User 123456 started lead conversation
INFO leads.bot: User 123456 provided name: John Doe
INFO leads.bot: User 123456 provided phone via text: +380671234567
INFO leads.bot: Lead #1 created for user 123456
INFO leads.bot: Email notification sent for lead #1
INFO leads.bot: Telegram notification sent for lead #1 to admin 987654321
```

---

## 🔧 УСТРАНЕНИЕ ПРОБЛЕМ

### Бот не отвечает на /start

**Проверьте:**
1. Бот запущен: `ps aux | grep bot_runner`
2. Нет ошибок в логах
3. Интеграция добавлена в `bot_runner_aiogram.py`
4. Импорт корректный: `from leads.bot import register_handlers`

### Заявка не сохраняется

**Проверьте:**
1. Миграции применены: `python manage.py showmigrations leads`
2. Нет ошибок в логах
3. База данных доступна
4. Права пользователя бота

### Уведомления не приходят

**Email не приходит:**
1. Проверьте EMAIL настройки в settings.py
2. Проверьте .env файл
3. Проверьте что email указан в LeadBotConfig
4. Тест: `python manage.py shell`
   ```python
   from django.core.mail import send_mail
   send_mail('Test', 'Test message', 'from@example.com', ['to@example.com'])
   ```

**Telegram не приходит:**
1. Проверьте что admin_user_id указан в LeadBotConfig
2. Проверьте что ID корректный (используйте @userinfobot)
3. Бот должен иметь возможность писать пользователю (пользователь должен написать боту первым)

### Права доступа

**Пользователь не видит раздел в админке:**
1. Проверьте membership в группе "Lead Managers"
2. Или назначьте права напрямую:
   ```python
   from django.contrib.auth.models import User, Permission
   user = User.objects.get(username='manager')
   perm = Permission.objects.get(codename='can_view_leads')
   user.user_permissions.add(perm)
   ```

---

## 📝 КАСТОМИЗАЦИЯ

### Изменение текстов бота

Через админку:
1. **Настройки Lead Bot** → выберите конфигурацию
2. Раскройте **Тексты бота**
3. Измените нужные поля
4. Сохраните
5. Перезапустите бота (или бот подхватит изменения автоматически)

### Добавление дополнительных полей

1. Добавьте поле в `leads/models.py` в модель `Lead`
2. Добавьте состояние в `leads/bot/states.py`
3. Добавьте handler в `leads/bot/handlers.py`
4. Обновите `format_lead_summary` в `leads/bot/utils.py`
5. Создайте и примените миграцию:
   ```bash
   python manage.py makemigrations leads
   python manage.py migrate leads
   ```

### Изменение валидации телефона

Откройте `leads/bot/utils.py` и измените функцию `validate_phone`:

```python
def validate_phone(phone: str) -> tuple[bool, Optional[str]]:
    # Ваша логика валидации
    pass
```

---

## 📚 ДОПОЛНИТЕЛЬНЫЕ МАТЕРИАЛЫ

- **Документация**: см. `leads/README.md`
- **Пример интеграции**: см. `leads/integration_example.py`
- **Команды настройки**: см. `leads/setup_commands.py`

---

## 🎉 ГОТОВО!

После выполнения всех шагов:
- ✅ Бот принимает заявки
- ✅ Заявки сохраняются в БД
- ✅ Уведомления отправляются
- ✅ Админка настроена с правами доступа
- ✅ Все работает!

**Если возникли вопросы** - проверьте логи и раздел "Устранение проблем" выше.

---

**Автор**: Claude  
**Дата создания**: 2025-10-02  
**Версия**: 1.0
