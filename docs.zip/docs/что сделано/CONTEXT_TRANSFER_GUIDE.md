# 🔄 Гайд для переноса контекста в новый чат

**Дата последнего обновления:** 2025-10-20  
**Проект:** Django + Telegram Bot + WayForPay Payment Integration

---

## 📦 ЧТО ПРИКРЕПИТЬ К НОВОМУ ЧАТУ

### 1. ОБЯЗАТЕЛЬНЫЕ файлы (всегда):
```
✅ CONTEXT_TRANSFER_GUIDE.md - этот файл (всегда актуальный!)
✅ SESSION_SUMMARY_2025-10-20.md - последняя сессия ⭐ UPDATED
✅ COMPLETE_WORKFLOW_GUIDE.md - полный гайд по payment workflow
✅ class_diagram.puml - архитектура (8 основных моделей)
✅ sequence_diagram.puml - полный payment flow
```

### 2. Ключевые файлы кода (если нужен контекст реализации):
```
✅ payments/wayforpay/services.py - WayForPayService (основная логика)
✅ payments/wayforpay/api.py - WayForPayAPI (работа с WFP API)
✅ payments/wayforpay/views.py - InvoiceCreateView, WebhookView, ReturnView
✅ payments/models.py - Invoice, VerifiedUser, MerchantConfig
✅ subscriptions/models.py - Subscription, Plan
✅ core/models.py - TelegramUser, Bot
✅ bot/subscriptions.py - bot handlers (on_pay, on_status, on_renew)
```

### 3. Тесты (если работаем над багами):
```
✅ tests/payment/test_new_order_reference_format.py - текущий failing test
✅ tests/payment/test_webhook_basic.py
✅ tests/payment/scenarios.yml - все сценарии тестирования
✅ tests/bot/scenarios.yml - сценарии для бота
```

---

## 🎯 ТЕКУЩИЙ СТАТУС ПРОЕКТА

### ✅ ЧТО РЕАЛИЗОВАНО:

**Основная архитектура:**
- ✅ Django backend с REST API
- ✅ Telegram bot на aiogram v3
- ✅ Интеграция с WayForPay API
- ✅ Multi-bot система (разные MerchantConfig для каждого бота)
- ✅ Webhook обработка платежей
- ✅ Система подписок с продлением
- ✅ Верификация пользователей

**База данных (8 основных моделей):**
- `Bot` - Telegram боты
- `TelegramUser` - пользователи
- `MerchantConfig` - конфигурация WayForPay для каждого бота
- `Plan` - тарифные планы
- `Invoice` - счета на оплату (PENDING → APPROVED/DECLINED)
- `Subscription` - подписки пользователей
- `VerifiedUser` - верифицированные пользователи (антифрод)
- `PaymentStatus` - enum статусов платежей

**WayForPayService методы:**
- ✅ `create_invoice()` - создание invoice и получение payment URL
- ✅ `handle_webhook()` - обработка webhook от WayForPay
- ✅ `_update_invoice_fields()` - обновление полей invoice ⭐ FIXED
- ✅ `_update_or_create_invoice()` - создание/обновление invoice ⭐ FIXED
- ✅ `_update_verified_user()` - верификация пользователя ⭐ FIXED
- ✅ `_process_payment_status()` - маршрутизация по статусу
- ✅ `_handle_approved_payment()` - обработка APPROVED
- ✅ `_handle_declined_payment()` - обработка DECLINED
- ✅ `_setup_new_subscription()` - создание новой подписки
- ✅ `_extend_subscription()` - продление существующей
- ✅ `_handle_payment_notification()` - debounce логика уведомлений

**WayForPayAPI методы:**
- ✅ `generate_payment_form_data()` - генерация данных для WFP
- ✅ `parse_order_reference()` - парсинг нового формата ORDER_timestamp+rand_user_plan
- ✅ `validate_response_signature()` - проверка HMAC подписи
- ✅ `get_signature()` - генерация подписи

**Telegram Bot handlers:**
- ✅ `/start` - главное меню
- ✅ `on_status` - показать статус подписки
- ✅ `on_renew` - список планов для продления
- ✅ `on_pay` - создание invoice и кнопка оплаты
- ✅ `on_help` - справка

**Тестирование:**
- ✅ 50+ тестов для payment flow
- ✅ 20+ тестов для bot handlers
- ✅ Сценарии покрытия (S1-S18, B1-B10)

---

## 🚧 НА КАКОМ ЭТАПЕ ОСТАНОВИЛИСЬ

**Последняя задача:**
```
🔧 Исправление теста test_webhook_with_new_format
```

**Что СДЕЛАНО (2025-10-20):**

**1. Исправлена модель Invoice (issuer_country):**
- ❌ Проблема: WayForPay присылал `'Ukraine'` (7 символов) → поле max_length=3
- ✅ Решение: Обрезка до 3 символов в `_update_invoice_fields()` и `_update_or_create_invoice()`
```python
issuer_country = payload.get('issuerBankCountry')
if issuer_country:
    issuer_country = issuer_country[:3].upper()  # "Ukraine" → "UKR"
```

**2. Исправлена модель VerifiedUser:**
- ❌ Проблема: Пытались записать несуществующие поля `card_type`, `fee`, `verified`
- ✅ Решение: Убрали эти поля из `_update_verified_user()`, оставили только:
  - `card_masked`, `payment_system`, `issuer_bank`
  - `first_payment_date`, `last_payment_date`
  - `total_amount_paid`, `successful_payments_count`

**3. Добавлено поле paid_at в Invoice:**
- ❌ Проблема: Тест проверяет `assert inv.paid_at is not None`, но поле не заполнялось
- ✅ Решение: Добавлено в `_update_or_create_invoice()`:
```python
'paid_at': timezone.now() if status == 'APPROVED' else None,
```

**4. Текущая проблема:**
```
FAILED: Subscription.DoesNotExist - подписка не найдена
ERROR: IntegrityError - foreign key constraint в subscriptions
```

Скорее всего проблема в:
- ForeignKey `user` vs `user_id` (нужен объект TelegramUser, не ID)
- Или в методе создания Subscription

---

## 📂 СТРУКТУРА ПРОЕКТА

```
profiling/  (Django project)
├── config/
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── core/
│   ├── models.py           # TelegramUser, Bot
│   └── admin.py
├── subscriptions/
│   ├── models.py           # Subscription, Plan, SubscriptionStatus
│   ├── services.py         # SubscriptionService
│   └── admin.py
├── payments/
│   ├── models.py           # Invoice, VerifiedUser, MerchantConfig, PaymentStatus
│   ├── wayforpay/
│   │   ├── api.py          # WayForPayAPI (подписи, парсинг)
│   │   ├── services.py     # WayForPayService (основная логика) ⭐ FIXED
│   │   └── views.py        # InvoiceCreateView, WebhookView, ReturnView
│   └── admin.py
├── bot/
│   ├── main.py             # (старый, не используется)
│   ├── subscriptions.py    # handlers для aiogram ⭐ ACTIVE
│   ├── keyboards.py        # inline keyboards
│   ├── config.py           # pydantic settings
│   └── notifications.py    # notify_payment_success, notify_payment_non_success
├── botops/
│   └── supervisor.py       # управление процессами ботов
├── bot_runner_aiogram.py   # запуск бота (longpoll/webhook)
├── tests/
│   ├── payment/
│   │   ├── test_new_order_reference_format.py ⭐ FAILING
│   │   ├── test_webhook_basic.py
│   │   ├── test_webhook_retry.py
│   │   └── scenarios.yml
│   └── bot/
│       ├── test_b*.py
│       └── scenarios.yml
├── manage.py
├── pytest.ini
└── requirements.txt
```

---

## 🎯 КЛЮЧЕВЫЕ КОНЦЕПЦИИ ПРОЕКТА

### 1. Order Reference Format (НОВЫЙ):
```
Формат: ORDER_timestamp+random3_user_plan
Пример: ORDER_1758606042kjI_407673079_2

Структура:
- PREFIX: ORDER_
- timestamp (секунды): 1758606042
- random 3 символа: kjI
- user_id (telegram): 407673079
- plan_id: 2

Парсинг: WayForPayAPI.parse_order_reference()
```

### 2. Payment Flow:
```
User → Bot → Django API (create-invoice)
                ↓
        WayForPay API (CREATE_INVOICE)
                ↓
        invoiceUrl → User оплачивает
                ↓
        WayForPay → Webhook → Django
                ↓
        WayForPayService.handle_webhook()
                ↓
        Create/Extend Subscription
                ↓
        Bot notification → User
```

### 3. Subscription Logic:
- **Новая подписка**: `starts_at = now`, `expires_at = now + duration_days`
- **Продление**: `expires_at = max(current_expires_at, now) + duration_days`
- **Один пользователь + один бот = одна активная подписка**
- **При оплате другого плана того же бота**: подписка продлевается, но НЕ меняет plan

### 4. Debounce Logic (уведомления):
```python
# Не отправлять уведомление если есть другой успешный платёж 
# за последние 10 минут
recent_success = Invoice.objects.filter(
    user_id=user_id,
    bot_id=bot_id,
    payment_status=PaymentStatus.APPROVED,
    paid_at__gte=timezone.now() - timedelta(minutes=10),  # ⭐ ИСПРАВЛЕНО
    paid_at__isnull=False
).exclude(order_reference=current_reference).exists()

if not recent_success:
    # Отправить уведомление
```

### 5. Multi-Bot System:
- Каждый `Bot` имеет свой `MerchantConfig` (свои credentials WayForPay)
- Каждый `Plan` привязан к `bot_id`
- Подписки изолированы по `bot_id`
- Один пользователь может иметь подписки у разных ботов

---

## 🔧 ИСПРАВЛЕНИЯ В ЭТОЙ СЕССИИ

### Файл: `payments/wayforpay/services.py`

**1. Метод `_update_invoice_fields()` (строка ~245):**
```python
def _update_invoice_fields(self, invoice: Invoice, payload: Dict):
    """Обновление полей инвойса без перезаписи существующих значений"""
    
    # ИСПРАВЛЕНО: обрезаем issuer_country до 3 символов
    issuer_country = payload.get('issuerBankCountry')
    if issuer_country:
        issuer_country = issuer_country[:3].upper()
    
    invoice.phone = invoice.phone or payload.get('phone')
    invoice.email = invoice.email or payload.get('email') 
    invoice.card_pan = invoice.card_pan or payload.get('cardPan')
    invoice.card_type = invoice.card_type or payload.get('cardType')
    invoice.issuer_bank = invoice.issuer_bank or payload.get('issuerBankName')
    invoice.issuer_country = invoice.issuer_country or issuer_country  # ОБРАБОТАННОЕ
    invoice.payment_system = invoice.payment_system or payload.get('paymentSystem')
    invoice.fee = invoice.fee or payload.get('fee')
    invoice.rrn = invoice.rrn or payload.get('rrn')
    invoice.approval_code = invoice.approval_code or payload.get('approvalCode')
    invoice.terminal = invoice.terminal or payload.get('terminal')
    invoice.reason_code = invoice.reason_code or payload.get('reasonCode')
    invoice.save()
```

**2. Метод `_update_or_create_invoice()` (строка ~388):**
```python
def _update_or_create_invoice(self, base_reference: str, payload: Dict, 
                              bot_id: int, user_id: int, plan_id: int, 
                              amount: float, status: str):
    """Создание/обновление инвойса"""
    import logging
    from django.utils import timezone
    logger = logging.getLogger(__name__)
    
    # ИСПРАВЛЕНО: обрезаем issuer_country до 3 символов
    issuer_country = payload.get('issuerBankCountry')
    if issuer_country:
        issuer_country = issuer_country[:3].upper()
    
    Invoice.objects.update_or_create(
        order_reference=base_reference,
        defaults={
            'bot_id': bot_id,
            'user_id': user_id,
            'plan_id': plan_id,
            'amount': amount,
            'payment_status': status,
            'paid_at': timezone.now() if status == 'APPROVED' else None,  # ⭐ ДОБАВЛЕНО
            'transaction_id': payload.get('rrn'),
            'rec_token': payload.get('recToken'),
            'phone': payload.get('phone'),
            'email': payload.get('email'),
            'card_pan': payload.get('cardPan'),
            'card_type': payload.get('cardType'),
            'issuer_bank': payload.get('issuerBankName'),
            'issuer_country': issuer_country,  # ⭐ ОБРАБОТАННОЕ
            'payment_system': payload.get('paymentSystem'),
            'fee': payload.get('fee'),
            'rrn': payload.get('rrn'),
            'approval_code': payload.get('approvalCode'),
            'terminal': payload.get('terminal'),
            'reason_code': payload.get('reasonCode'),
        }
    )
```

**3. Метод `_update_verified_user()` (строка ~xxx):**
```python
def _update_verified_user(self, bot_id: int, user_id: int, payload: Dict):
    """Обновление верифицированного пользователя"""
    import logging
    from payments.models import VerifiedUser
    from core.models import TelegramUser
    from django.utils import timezone
    
    logger = logging.getLogger(__name__)
    
    # Получаем user объект (не ID!)
    user = TelegramUser.objects.get(user_id=user_id)
    
    # ⭐ ИСПРАВЛЕНО: используем только поля которые есть в модели
    VerifiedUser.objects.update_or_create(
        bot_id=bot_id,
        user=user,  # ForeignKey!
        defaults={
            'first_payment_date': timezone.now(),
            'card_masked': payload.get('cardPan'),
            'payment_system': payload.get('paymentSystem'),
            'issuer_bank': payload.get('issuerBankName'),
            'last_payment_date': timezone.now(),
            'total_amount_paid': 0,  # будет обновлено через update_payment_stats
            'successful_payments_count': 1,
        }
    )
```

---

## 📋 TODO (что делать дальше)

### Immediate (текущая проблема):

**Исправить IntegrityError в Subscription:**
1. [ ] Найти где создаётся Subscription
2. [ ] Проверить что передаётся `user` (объект), не `user_id` (int)
3. [ ] Посмотреть метод `_handle_approved_payment()` или `_setup_new_subscription()`
4. [ ] Запустить тест: 
```bash
pytest tests/payment/test_new_order_reference_format.py::TestNewOrderReferenceFormat::test_webhook_with_new_format -v
```

### Потом:
- [ ] Пройти все remaining tests
- [ ] Проверить bot handlers (B9.1, B9.2)
- [ ] Deployment на production

---

## 💡 ВАЖНЫЕ ДЕТАЛИ

### Модель Invoice (payments/models.py):
```python
class Invoice(models.Model):
    # Обязательные
    order_reference = CharField(max_length=255, unique=True)
    user = ForeignKey(TelegramUser)  # объект!
    plan = ForeignKey(Plan)
    bot_id = IntegerField()
    amount = DecimalField()
    currency = CharField(max_length=100)
    payment_status = CharField()  # NEW/PENDING/APPROVED/DECLINED/REFUNDED/EXPIRED
    
    # WayForPay данные
    transaction_id = CharField(max_length=255)
    card_pan = CharField(max_length=20)
    card_type = CharField(max_length=50)
    issuer_bank = CharField(max_length=100)
    issuer_country = CharField(max_length=3)  # ⭐ КОД СТРАНЫ (UA, US, UK)
    payment_system = CharField(max_length=50)
    fee = DecimalField()
    rrn = CharField(max_length=50)
    approval_code = CharField(max_length=50)
    terminal = CharField(max_length=50)
    rec_token = CharField(max_length=255)
    reason_code = CharField(max_length=191)
    
    # Контакты
    phone = CharField(max_length=20)
    email = EmailField()
    
    # Временные метки
    paid_at = DateTimeField()  # ⭐ КОГДА ОПЛАЧЕН
    created_at = DateTimeField()
    updated_at = DateTimeField()
```

### Модель VerifiedUser (payments/models.py):
```python
class VerifiedUser(models.Model):
    user = ForeignKey(TelegramUser)  # ⭐ ForeignKey!
    bot_id = IntegerField()
    
    # Первый платёж
    first_payment_date = DateTimeField()  # ⭐ NOT NULL
    card_masked = CharField(max_length=20)
    payment_system = CharField(max_length=50)
    issuer_bank = CharField(max_length=100)
    
    # Статистика
    successful_payments_count = IntegerField(default=1)
    total_amount_paid = DecimalField()  # ⭐ NOT NULL
    last_payment_date = DateTimeField()
    
    # ❌ НЕТ полей: card_type, fee, verified
```

### Модель Subscription (subscriptions/models.py):
```python
class Subscription(models.Model):
    user = ForeignKey(TelegramUser)  # ⭐ ForeignKey!
    plan = ForeignKey(Plan)
    bot_id = IntegerField()
    
    status = CharField()  # active/expired/canceled
    starts_at = DateTimeField()
    expires_at = DateTimeField()
    last_payment_date = DateTimeField()
    
    # Рекуррентные
    card_token = CharField()
    card_masked = CharField()
    recurrent_status = CharField()
    
    # Уникальность
    class Meta:
        unique_together = ('user', 'plan', 'bot_id')
```

---

## 🚨 ИЗВЕСТНЫЕ ПРОБЛЕМЫ

**РЕШЕНО:**
- ✅ `issuer_country` too long → обрезка до 3 символов
- ✅ `card_type`, `fee`, `verified` не существуют в VerifiedUser → убрали
- ✅ `first_payment_date` NULL constraint → добавили значение
- ✅ `paid_at` не заполнялось → добавили в defaults

**АКТУАЛЬНЫЕ:**
- ❌ Subscription.DoesNotExist
- ❌ IntegrityError: foreign key constraint "subscriptions_user_id_..."

**Гипотеза:**
Где-то передаём `user_id` (int) вместо `user` (объект TelegramUser)

---

## 📚 КОНТЕКСТ ИЗ ПРЕДЫДУЩИХ ЧАТОВ

### Архитектурные решения:

**1. Новый формат orderReference:**
- Старый: `bot_user_plan_timestamp`
- Новый: `ORDER_timestamp+rand_user_plan`
- Причина: лучше соответствует требованиям WayForPay

**2. Debounce для уведомлений:**
- Проблема: дублирование уведомлений при быстрых платежах
- Решение: проверка `paid_at` (не `created_at`)
- Окно: 10 минут

**3. Multi-Bot:**
- Одна база, много ботов
- Изоляция по `bot_id`
- Каждый бот имеет свой MerchantConfig

**4. Верификация пользователей:**
- После первого успешного платежа
- Для антифрод системы
- Статистика платежей

---

## 🔄 ОБНОВЛЕНИЯ ЭТОГО ГАЙДА

**Когда обновлять:**
- После исправления бага
- После добавления функционала
- Перед переносом в новый чат
- Когда меняется архитектура

**Что обновлять:**
- Секцию "ТЕКУЩИЙ СТАТУС"
- Секцию "НА КАКОМ ЭТАПЕ ОСТАНОВИЛИСЬ"
- Секцию "TODO"
- Секцию "ИЗВЕСТНЫЕ ПРОБЛЕМЫ"
- Дату вверху файла

---

## 📞 БЫСТРЫЙ СТАРТ В НОВОМ ЧАТЕ

**Скажи Claude:**

> Привет! Продолжаем работу над Django + WayForPay проектом.
> Прикрепляю файлы:
> - CONTEXT_TRANSFER_GUIDE.md
> - SESSION_SUMMARY_2025-10-20.md
> - COMPLETE_WORKFLOW_GUIDE.md
> - class_diagram.puml
> - sequence_diagram.puml
> 
> Мы остановились на: Исправление IntegrityError в Subscription при обработке webhook
> 
> Текущая ошибка:
> ```
> IntegrityError: insert or update on table "subscriptions" 
> violates foreign key constraint "subscriptions_user_id_..."
> ```
> 
> Прочитай контекст и скажи что понял, потом продолжим.

**Claude должен:**
1. Прочитать файлы
2. Понять архитектуру (8 моделей, payment flow)
3. Понять что уже исправлено (issuer_country, VerifiedUser, paid_at)
4. Понять текущую проблему (ForeignKey constraint)
5. Предложить где искать проблему
6. Продолжить работу

---

*Этот файл - живой документ. Обновляется после каждой сессии.*

*Последнее обновление: 2025-10-20*