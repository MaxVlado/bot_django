# 📖 COMPLETE WORKFLOW GUIDE
## WayForPay Payment Integration - От Invoice до Subscription

**Обновлено:** 2025-10-20  
**Версия:** 1.0  
**Проект:** Django + Telegram Bot + WayForPay

---

## 🎯 Обзор процесса

Полный цикл оплаты проходит через **7 этапов**:

```
1. USER ACTION (Пользователь выбирает план) ✅
   ↓
2. INVOICE CREATION (Создание invoice и получение URL) ✅
   ↓
3. PAYMENT PROCESS (Оплата на стороне WayForPay) ✅
   ↓
4. WEBHOOK PROCESSING (Обработка уведомления) ✅
   ↓
5. SUBSCRIPTION MANAGEMENT (Создание/продление подписки) ✅
   ↓
6. USER VERIFICATION (Верификация пользователя) ✅
   ↓
7. NOTIFICATION (Уведомление пользователя) ✅
```

**Общее время цикла:**
- Invoice creation: ~1-2 секунды
- Payment process: ~30-60 секунд (действия пользователя)
- Webhook processing: ~100-500ms
- User notification: ~500ms

---

## ⚙️ Этап 1: USER ACTION - Пользователь выбирает план

### 🎯 Цель:
Пользователь в Telegram боте выбирает тарифный план для оплаты.

### 📝 Что происходит:

#### Шаг 1.1: Пользователь открывает бота
```
User → Bot: /start
Bot → User: Главное меню с кнопками:
  - 📋 Моя подписка
  - 💳 Продлить подписку
  - ❓ Помощь
```

**Код:** `bot/subscriptions.py → cmd_start()`
```python
async def cmd_start(message: types.Message, pool):
    is_blocked = await pool.fetchval(SQL_IS_BLOCKED, message.from_user.id)
    if is_blocked:
        await message.answer("⛔ Доступ запрещён.")
        return
    
    await message.answer(
        "Привет! Это меню управления подпиской.",
        reply_markup=kb_main_menu()
    )
```

#### Шаг 1.2: Пользователь нажимает "Продлить подписку"
```
User → Bot: callback "sub:renew"
Bot → Database: SELECT plans WHERE bot_id=X AND enabled=TRUE
Bot → User: Список доступных планов:
  - План 1: 50 UAH / 7 дней
  - План 2: 150 UAH / 30 дней
```

**Код:** `bot/subscriptions.py → on_renew()`
```python
async def on_renew(cb: types.CallbackQuery, pool, bot_model):
    blocked = await pool.fetchval(SQL_IS_BLOCKED, cb.from_user.id)
    if blocked:
        await cb.answer("Доступ запрещён", show_alert=True)
        return
    
    rows = await pool.fetch(SQL_PLANS_ENABLED, bot_model.id)
    plans = [r for r in rows if r.get("enabled", True)]
    
    if not plans:
        await cb.message.edit_text("Нет доступных тарифов.")
        return
    
    kb = kb_plans(plans)
    await cb.message.edit_text("Выберите тариф:", reply_markup=kb)
```

#### Шаг 1.3: Пользователь выбирает план
```
User → Bot: callback "pay:7" (plan_id=7)
Bot → Django API: POST /create-invoice/
```

**Переход к Этапу 2** ⬇️

---

## ⚙️ Этап 2: INVOICE CREATION - Создание invoice

### 🎯 Цель:
Создать invoice в базе и получить payment URL от WayForPay.

### 📝 Что происходит:

#### Шаг 2.1: Bot отправляет запрос в Django API
```python
# bot/subscriptions.py → on_pay()
payload = {
    "bot_id": bot_model.id,
    "user_id": cb.from_user.id,
    "plan_id": plan_id
}
url = f"{bot_model.merchant_config.django_api_base}/create-invoice/"

async with session.post(url, json=payload, timeout=20) as resp:
    data = await resp.json()
    # data = {"ok": true, "invoiceUrl": "https://..."}
```

#### Шаг 2.2: Django API вызывает WayForPayService
```python
# payments/wayforpay/views.py → InvoiceCreateView
class InvoiceCreateView(APIView):
    def post(self, request):
        bot_id = request.data.get('bot_id')
        user_id = request.data.get('user_id')
        plan_id = request.data.get('plan_id')
        
        service = WayForPayService(bot_id=bot_id)
        invoice_url = service.create_invoice(
            bot_id=bot_id,
            user_id=user_id,
            plan_id=plan_id
        )
        
        return JsonResponse({
            "ok": True,
            "invoiceUrl": invoice_url
        })
```

#### Шаг 2.3: WayForPayService создаёт invoice
```python
# payments/wayforpay/services.py → create_invoice()
@transaction.atomic
def create_invoice(self, bot_id: int, user_id: int, plan_id: int, amount: Optional[Decimal] = None) -> str:
    # 1. Получаем Plan
    plan = Plan.objects.get(id=plan_id, bot_id=bot_id, enabled=True)
    
    # 2. Получаем/создаём TelegramUser
    user, _ = TelegramUser.objects.get_or_create(
        user_id=user_id,
        defaults={"username": None, "first_name": None}
    )
    
    # 3. Генерируем order_reference
    order_reference = Invoice.generate_order_reference(
        bot_id=bot_id,
        user_id=user_id,
        plan_id=plan_id
    )
    # Результат: "ORDER_1758606042kjI_407673079_7"
    
    # 4. Создаём Invoice в БД (PENDING)
    inv = Invoice.objects.create(
        order_reference=order_reference,
        user=user,
        plan=plan,
        bot_id=bot_id,
        amount=amount or plan.price,
        currency=plan.currency,
        payment_status=PaymentStatus.PENDING
    )
    
    # 5. Готовим данные для WayForPay API
    payload = {
        "orderReference": inv.order_reference,
        "amount": int(inv.amount),
        "currency": inv.currency,
        "productName": [plan.name],
        "productCount": [1],
        "productPrice": [int(inv.amount)]
    }
    
    # 6. Генерируем form_data с подписью
    form_data = self.api.generate_payment_form_data(payload)
    
    # 7. Отправляем в WayForPay API
    response = requests.post(
        'https://api.wayforpay.com/api',
        json=form_data,
        timeout=30
    )
    
    result = response.json()
    invoice_url = result.get('invoiceUrl')
    
    # 8. Сохраняем raw_request_payload
    inv.raw_request_payload = form_data
    inv.save(update_fields=["raw_request_payload"])
    
    return invoice_url
```

#### Шаг 2.4: WayForPayAPI генерирует подпись
```python
# payments/wayforpay/api.py → generate_payment_form_data()
def generate_payment_form_data(self, invoice_data: Dict) -> Dict:
    form_data = {
        "transactionType": "CREATE_INVOICE",
        "apiVersion": 1,
        "merchantAccount": self.merchant_account,
        "merchantDomainName": self.domain_name,
        "orderReference": invoice_data["orderReference"],
        "orderDate": int(time.time()),
        "amount": int(invoice_data["amount"]),
        "currency": invoice_data["currency"],
        "productName": invoice_data["productName"],
        "productCount": invoice_data["productCount"],
        "productPrice": invoice_data["productPrice"],
        "returnUrl": self.return_url,
        "serviceUrl": self.service_url,
        "language": "UA"
    }
    
    # Генерируем HMAC-MD5 подпись
    form_data["merchantSignature"] = self.get_request_signature(form_data)
    
    return form_data
```

#### Шаг 2.5: Bot отправляет кнопку пользователю
```python
# bot/subscriptions.py → on_pay()
if data.get("ok"):
    invoice_url = data["invoiceUrl"]
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Оплатить", url=invoice_url)],
        [InlineKeyboardButton(text="⬅ Назад", callback_data="ui:back")]
    ])
    
    await cb.message.edit_text(
        "Перейдите по кнопке «Оплатить». "
        "После оплаты вернитесь и нажмите «Моя подписка».",
        reply_markup=kb
    )
```

### ✅ Критерий готовности:
- [x] Invoice создан в БД со статусом PENDING
- [x] order_reference сгенерирован (формат ORDER_...)
- [x] invoiceUrl получен от WayForPay
- [x] Кнопка "Оплатить" отправлена пользователю

**Переход к Этапу 3** ⬇️

---

## ⚙️ Этап 3: PAYMENT PROCESS - Оплата

### 🎯 Цель:
Пользователь оплачивает invoice на стороне WayForPay.

### 📝 Что происходит:

#### Шаг 3.1: Пользователь нажимает кнопку "Оплатить"
```
User → WayForPay: переход по invoiceUrl
WayForPay → User: форма оплаты
  - Номер карты
  - Срок действия
  - CVV
  - Имя держателя
```

#### Шаг 3.2: Пользователь вводит данные карты
```
User → WayForPay: данные карты
WayForPay → Bank: проверка карты и списание
Bank → WayForPay: результат (APPROVED/DECLINED)
```

#### Шаг 3.3: WayForPay обрабатывает результат
```
Если APPROVED:
  - Деньги списаны
  - Генерируется recToken (для рекуррентов)
  - Готовятся данные для webhook

Если DECLINED:
  - Деньги не списаны
  - Причина отказа (insufficient_funds, wrong_cvv, etc)
```

### ⏱️ Время этапа:
- Ввод данных: 20-40 секунд
- Проверка банком: 5-10 секунд
- **Всего: 30-60 секунд**

**Переход к Этапу 4** ⬇️

---

## ⚙️ Этап 4: WEBHOOK PROCESSING - Обработка уведомления

### 🎯 Цель:
Получить и обработать webhook от WayForPay о результате оплаты.

### 📝 Что происходит:

#### Шаг 4.1: WayForPay отправляет webhook
```
WayForPay → Django: POST /api/payments/wayforpay/webhook/

Payload:
{
  "merchantAccount": "test_merchant",
  "orderReference": "ORDER_1758606042kjI_407673079_7",
  "amount": 150,
  "currency": "UAH",
  "transactionStatus": "Approved",
  "reasonCode": "1100",
  "transactionId": "TX-12345",
  "cardPan": "444455******1111",
  "cardType": "Visa",
  "issuerBankName": "PrivatBank",
  "issuerBankCountry": "Ukraine",
  "paymentSystem": "visa",
  "recToken": "token_abc123...",
  "merchantSignature": "abc123def456..."
}
```

#### Шаг 4.2: Django API вызывает WebhookView
```python
# payments/wayforpay/views.py → WebhookView
class WebhookView(APIView):
    def post(self, request):
        payload = request.data
        
        service = WayForPayService()
        result = service.handle_webhook(payload)
        
        return JsonResponse(result)
```

#### Шаг 4.3: WayForPayService.handle_webhook()
```python
# payments/wayforpay/services.py
@transaction.atomic
def handle_webhook(self, payload: Dict) -> Dict:
    logger.info(f'Received webhook: {payload}')
    
    # 1. Проверка подписи (если включена)
    if settings.WAYFORPAY_VERIFY_SIGNATURE:
        if not self.api.validate_response_signature(payload):
            logger.error('Invalid signature')
            return {"status": "error", "message": "Invalid signature"}
    
    # 2. Проверка валюты
    if payload.get('currency') != 'UAH':
        logger.warning(f"Invalid currency: {payload.get('currency')}")
        return {"message": "Unsupported currency"}
    
    # 3. Получаем orderReference
    order_reference = payload.get('orderReference', '').strip().rstrip(';')
    
    if not order_reference:
        logger.error("orderReference is missing")
        return {"status": "error", "message": "orderReference required"}
    
    # 4. Парсим orderReference
    try:
        user_id, plan_id, timestamp = self.api.parse_order_reference(order_reference)
        logger.info(f"✅ Parsed: user_id={user_id}, plan_id={plan_id}")
    except ValueError as e:
        logger.error(f"❌ Parse failed: {e}")
        
        # FALLBACK: прямой поиск Invoice
        invoice = Invoice.objects.filter(
            order_reference=order_reference
        ).select_related('user', 'plan').first()
        
        if not invoice:
            return {"status": "error", "message": "Invoice not found"}
        
        user_id = invoice.user.user_id
        plan_id = invoice.plan_id
        bot_id = invoice.bot_id
        
        base_reference = order_reference.split('_WFPREG-')[0]
        return self._process_payment_status(payload, user_id, plan_id, bot_id, base_reference)
    
    # 5. Получаем Plan и bot_id
    plan = Plan.objects.filter(id=plan_id, enabled=True).first()
    if not plan:
        return {"status": "error", "message": "Plan not available"}
    
    bot_id = plan.bot_id
    
    # 6. Проверка дубликатов (debounce)
    base_reference = order_reference.split('_WFPREG-')[0]
    
    existing_invoice = Invoice.objects.filter(
        order_reference=base_reference,
        payment_status=PaymentStatus.APPROVED
    ).first()
    
    if existing_invoice:
        logger.info(f"🔄 Duplicate webhook for: {order_reference}")
        self._update_invoice_fields(existing_invoice, payload)
        return {"status": "accepted"}
    
    # 7. Обработка платежа
    return self._process_payment_status(payload, user_id, plan_id, bot_id, base_reference)
```

#### Шаг 4.4: Обработка статуса платежа
```python
def _process_payment_status(self, payload: Dict, user_id: int, plan_id: int, 
                            bot_id: int, base_reference: str) -> Dict:
    transaction_status = payload.get('transactionStatus', '').upper()
    
    plan = Plan.objects.get(id=plan_id)
    
    if transaction_status == 'APPROVED':
        return self._handle_approved_payment(payload, user_id, plan_id, bot_id, base_reference)
    elif transaction_status in ['DECLINED', 'EXPIRED', 'CANCELED']:
        return self._handle_declined_payment(payload, user_id, plan_id, bot_id, base_reference)
    else:
        # PENDING, IN_PROCESS, WAITING_AUTH_COMPLETE
        return {"status": "pending"}
```

### ✅ Критерий готовности:
- [x] Webhook получен
- [x] Подпись проверена
- [x] orderReference распарсен
- [x] Статус обработан (APPROVED/DECLINED/...)

**Переход к Этапу 5** ⬇️

---

## ⚙️ Этап 5: SUBSCRIPTION MANAGEMENT - Управление подпиской

### 🎯 Цель:
Создать новую или продлить существующую подписку.

### 📝 Что происходит (при APPROVED):

#### Шаг 5.1: Обработка успешного платежа
```python
def _handle_approved_payment(self, payload: Dict, user_id: int, plan_id: int, 
                            bot_id: int, base_reference: str) -> Dict:
    logger.info(f"Processing APPROVED payment for user {user_id}")
    
    # 1. Получаем данные
    plan = Plan.objects.get(id=plan_id)
    user = TelegramUser.objects.get(user_id=user_id)
    amount = Decimal(str(payload.get('amount', plan.price)))
    transaction_id = payload.get('transactionId')
    duration_days = plan.duration_days
    
    # 2. Ищем существующую подписку
    subscription = Subscription.objects.filter(
        user=user,
        bot_id=bot_id
    ).first()
    
    if not subscription:
        # Новая подписка
        logger.info("Creating new subscription")
        subscription = Subscription.objects.create(
            user=user,
            plan=plan,
            bot_id=bot_id,
            status=SubscriptionStatus.ACTIVE,
            starts_at=timezone.now(),
            expires_at=timezone.now() + timedelta(days=duration_days),
            amount=amount,
            order_reference=base_reference,
            transaction_id=transaction_id
        )
        
        # Настройка рекуррентов
        self._setup_new_subscription(subscription, payload, duration_days)
    else:
        # Продление существующей
        logger.info(f"Extending subscription {subscription.id}")
        self._extend_subscription(subscription, duration_days)
        subscription.order_reference = base_reference
        subscription.transaction_id = transaction_id
        subscription.save()
    
    # 3. Создаём/обновляем инвойс
    self._update_or_create_invoice(base_reference, payload, bot_id, user_id, plan_id, amount, 'APPROVED')
    
    # 4. Создаём/обновляем VerifiedUser
    self._update_verified_user(bot_id, user_id, payload)
    
    # 5. Проверяем debounce и отправляем уведомление
    self._handle_payment_notification(bot_id, user_id, plan_id, base_reference, subscription)
    
    return {"status": "accepted"}
```

#### Шаг 5.2: Настройка новой подписки
```python
def _setup_new_subscription(self, subscription: Subscription, payload: Dict, duration_days: int):
    """Настройка новой подписки"""
    is_regular = payload.get('regularCreated') == True
    
    if is_regular:
        subscription.recurrent_status = 'Active'
        subscription.recurrent_mode = payload.get('regularMode', 'monthly')
        subscription.card_token = payload.get('recToken')
        subscription.recurrent_date_begin = timezone.now().date()
        subscription.recurrent_date_end = (timezone.now() + timedelta(days=365)).date()
        subscription.recurrent_next_payment = (timezone.now() + timedelta(days=duration_days)).date()
    
    subscription.reminder_sent_count = 0
    subscription.reminder_sent_at = None
    subscription.last_payment_date = timezone.now()
    subscription.save()
```

#### Шаг 5.3: Продление существующей подписки
```python
def _extend_subscription(self, subscription: Subscription, duration_days: int):
    """Продление подписки"""
    logger = logging.getLogger(__name__)
    
    current_expiration = subscription.expires_at
    now = timezone.now()
    
    # Якорь для продления: max(текущая_дата_окончания, сейчас)
    anchor = max(current_expiration, now) if current_expiration else now
    new_expiration = anchor + timedelta(days=duration_days)
    
    logger.info(f"Extending subscription {subscription.id}:")
    logger.info(f"  Current expires_at: {current_expiration}")
    logger.info(f"  Anchor: {anchor}")
    logger.info(f"  Duration: {duration_days} days")
    logger.info(f"  New expires_at: {new_expiration}")
    
    subscription.expires_at = new_expiration.date()
    subscription.last_payment_date = now.date()
    subscription.status = 'active'
    subscription.reminder_sent = 0
    subscription.reminder_sent_at = None
    
    subscription.save(update_fields=[
        'expires_at', 'last_payment_date', 'status', 
        'reminder_sent', 'reminder_sent_at', 'updated_at'
    ])
```

### ✅ Критерий готовности:
- [x] Subscription создана или продлена
- [x] expires_at обновлена корректно
- [x] status = ACTIVE
- [x] Рекуррентные данные сохранены (если есть)

**Переход к Этапу 6** ⬇️

---

## ⚙️ Этап 6: USER VERIFICATION - Верификация пользователя

### 🎯 Цель:
Создать/обновить запись VerifiedUser для антифрод системы.

### 📝 Что происходит:

#### Шаг 6.1: Создание/обновление VerifiedUser
```python
def _update_verified_user(self, bot_id: int, user_id: int, payload: Dict):
    """Обновление верифицированного пользователя"""
    from payments.models import VerifiedUser
    from core.models import TelegramUser
    from django.utils import timezone
    
    logger = logging.getLogger(__name__)
    
    # Получаем user объект (ForeignKey!)
    user = TelegramUser.objects.get(user_id=user_id)
    
    # Создаём или обновляем
    VerifiedUser.objects.update_or_create(
        bot_id=bot_id,
        user=user,  # ⭐ Объект, не ID!
        defaults={
            'first_payment_date': timezone.now(),
            'card_masked': payload.get('cardPan'),
            'payment_system': payload.get('paymentSystem'),
            'issuer_bank': payload.get('issuerBankName'),
            'last_payment_date': timezone.now(),
            'total_amount_paid': 0,  # будет обновлено
            'successful_payments_count': 1,
        }
    )
```

### ✅ Критерий готовности:
- [x] VerifiedUser создан или обновлён
- [x] Данные карты сохранены (маска)
- [x] Счётчики платежей обновлены

**Переход к Этапу 7** ⬇️

---

## ⚙️ Этап 7: NOTIFICATION - Уведомление пользователя

### 🎯 Цель:
Отправить уведомление пользователю в Telegram о результате оплаты.

### 📝 Что происходит:

#### Шаг 7.1: Debounce проверка
```python
def _handle_payment_notification(self, bot_id: int, user_id: int, plan_id: int, 
                                 base_reference: str, subscription):
    """Отправка уведомления с debounce логикой"""
    from django.utils import timezone
    from datetime import timedelta
    
    logger = logging.getLogger(__name__)
    
    # Проверяем: были ли другие успешные платежи за последние 10 минут?
    debounce_minutes = 10
    recent_success = Invoice.objects.filter(
        bot_id=bot_id,
        user_id=user_id,
        payment_status=PaymentStatus.APPROVED,
        paid_at__gte=timezone.now() - timedelta(minutes=debounce_minutes),  # ⭐ paid_at!
        paid_at__isnull=False
    ).exclude(order_reference=base_reference).exists()
    
    if recent_success:
        logger.info(f'Notification suppressed (debounce): user={user_id}')
    else:
        try:
            # Отправка уведомления через Telegram
            # self.telegram_service.notify_about_payment(bot_id, user_id, subscription.expires_at)
            logger.info(f'Payment notification sent to user {user_id}')
        except Exception as e:
            logger.error(f'Notification failed: {e}')
```

#### Шаг 7.2: Отправка уведомления через бота
```python
# bot/notifications.py
async def notify_payment_success(
    pool,
    bot_api,
    user_id: int,
    order_reference: str,
    plan_name: str,
    expires_at: datetime | None = None
) -> bool:
    """Отправка подтверждения об оплате"""
    
    # Проверка идемпотентности (не отправляли ли уже)
    already = await pool.fetchval(SQL_NOTIFY_WAS_SENT, order_reference)
    if already:
        return False
    
    expires_txt = ""
    if expires_at:
        expires_txt = f"\nДо: <b>{expires_at.strftime('%d.%m.%Y')}</b>"
    
    text = (
        f"✅ Платёж подтверждён!\n"
        f"Подписка <b>{plan_name}</b> активирована/продлена.{expires_txt}"
    )
    
    await bot_api.send_message(chat_id=user_id, text=text, parse_mode="HTML")
    
    # Помечаем как отправленное
    await pool.execute(SQL_NOTIFY_MARK_SENT, order_reference)
    
    return True
```

### ✅ Критерий готовности:
- [x] Debounce проверка пройдена
- [x] Уведомление отправлено (если не подавлено)
- [x] Запись в bot_payment_notifications создана

---

## 🎉 Готово!

Полный цикл завершён:
- ✅ Invoice создан
- ✅ Платёж обработан
- ✅ Subscription активирована/продлена
- ✅ VerifiedUser обновлён
- ✅ Пользователь уведомлён

---

## ⏱️ Timeline полного цикла

| Этап | Время |
|------|-------|
| User Action | ~5 секунд |
| Invoice Creation | ~1-2 секунды |
| Payment Process | ~30-60 секунд |
| Webhook Processing | ~100-500ms |
| Subscription Management | ~50-100ms |
| User Verification | ~20-50ms |
| Notification | ~500ms |
| **TOTAL** | **~40-70 секунд** |

---

## 📋 Полный чеклист для первого платежа

### Pre-Start:
- [ ] Django server running
- [ ] Telegram bot running
- [ ] WayForPay credentials настроены
- [ ] MerchantConfig создан для бота
- [ ] Plan создан и enabled=True

### Phase 1: Invoice Creation
- [ ] User выбрал план в боте
- [ ] Bot отправил POST /create-invoice/
- [ ] Invoice создан в БД (status=PENDING)
- [ ] orderReference сгенерирован
- [ ] WayForPay вернул invoiceUrl
- [ ] Кнопка "Оплатить" отправлена пользователю

### Phase 2: Payment
- [ ] User перешёл по invoiceUrl
- [ ] User ввёл данные карты
- [ ] WayForPay обработал платёж
- [ ] Результат: APPROVED или DECLINED

### Phase 3: Webhook Processing
- [ ] Webhook получен от WayForPay
- [ ] Подпись проверена (если verify_signature=True)
- [ ] orderReference распарсен
- [ ] user_id, plan_id извлечены
- [ ] Duplicate check пройден

### Phase 4: Subscription
- [ ] Subscription создана или найдена
- [ ] expires_at вычислена корректно
- [ ] status = ACTIVE
- [ ] last_payment_date обновлена
- [ ] Рекуррентные данные сохранены (если есть)

### Phase 5: Invoice Update
- [ ] Invoice обновлён (status=APPROVED)
- [ ] paid_at заполнен
- [ ] Данные карты сохранены (card_pan, issuer_bank, etc)
- [ ] issuer_country обрезан до 3 символов

### Phase 6: User Verification
- [ ] VerifiedUser создан или обновлён
- [ ] first_payment_date заполнен
- [ ] total_amount_paid обновлён
- [ ] successful_payments_count увеличен

### Phase 7: Notification
- [ ] Debounce проверка выполнена
- [ ] Уведомление отправлено (если не подавлено)
- [ ] bot_payment_notifications запись создана

### Post-Check:
- [ ] User видит уведомление в боте
- [ ] User может проверить статус подписки
- [ ] expires_at корректна в БД
- [ ] Все транзакции логируются

---

## ⚠️ Частые проблемы и решения

### Problem 1: issuer_country too long
**Симптом:** 
```
ERROR: value too long for type character varying(3)
```

**Причина:** WayForPay присылает полное название страны "Ukraine" (7 символов)

**Решение:**
```python
issuer_country = payload.get('issuerBankCountry')
if issuer_country:
    issuer_country = issuer_country[:3].upper()  # "Ukraine" → "UKR"
```

### Problem 2: Invalid field names для VerifiedUser
**Симптом:**
```
ERROR: Invalid field name(s): 'card_type', 'fee', 'verified'
```

**Причина:** Пытаемся записать поля которых нет в модели

**Решение:**
Проверить модель:
```bash
grep -A 20 "class VerifiedUser" payments/models.py
```
Убрать несуществующие поля из кода.

### Problem 3: NULL constraint для first_payment_date
**Симптом:**
```
ERROR: null value in column "first_payment_date" violates not-null constraint
```

**Причина:** Обязательное поле не заполняется при создании

**Решение:**
```python
VerifiedUser.objects.update_or_create(
    defaults={
        'first_payment_date': timezone.now(),  # ⭐ ОБЯЗАТЕЛЬНО
        'total_amount_paid': 0,  # ⭐ ОБЯЗАТЕЛЬНО
        ...
    }
)
```

### Problem 4: paid_at is None
**Симптом:**
```python
assert inv.paid_at is not None  # FAILS
```

**Причина:** Поле не заполняется при обработке APPROVED

**Решение:**
```python
Invoice.objects.update_or_create(
    defaults={
        'paid_at': timezone.now() if status == 'APPROVED' else None,
        ...
    }
)
```

### Problem 5: ForeignKey constraint violation
**Симптом:**
```
IntegrityError: foreign key constraint "subscriptions_user_id_..." violated
```

**Причина:** Передаём `user_id` (int) вместо `user` (объект)

**Решение:**
```python
# ❌ НЕПРАВИЛЬНО:
VerifiedUser.objects.create(user_id=123, ...)

# ✅ ПРАВИЛЬНО:
user = TelegramUser.objects.get(user_id=123)
VerifiedUser.objects.create(user=user, ...)
```

### Problem 6: Duplicate webhook обрабатывается дважды
**Симптом:** Подписка продлевается на двойной срок

**Причина:** Нет проверки на существующий APPROVED invoice

**Решение:**
```python
existing_invoice = Invoice.objects.filter(
    order_reference=base_reference,
    payment_status=PaymentStatus.APPROVED
).first()

if existing_invoice:
    # Только обновляем поля, не создаём subscription
    self._update_invoice_fields(existing_invoice, payload)
    return {"status": "accepted"}
```

### Problem 7: Debounce не работает
**Симптом:** Дублирующие уведомления при быстрых платежах

**Причина:** Используется `created_at` вместо `paid_at`

**Решение:**
```python
# ❌ НЕПРАВИЛЬНО:
recent_success = Invoice.objects.filter(
    created_at__gte=timezone.now() - timedelta(minutes=10)
)

# ✅ ПРАВИЛЬНО:
recent_success = Invoice.objects.filter(
    paid_at__gte=timezone.now() - timedelta(minutes=10),
    paid_at__isnull=False
)
```

---

## 💡 Best Practices

### Invoice Management:
1. **Всегда генерировать уникальный orderReference**
   - Формат: ORDER_timestamp+random3_user_plan
   - timestamp гарантирует уникальность
   - random 3 символа - дополнительная защита

2. **Сохранять raw_request_payload и raw_response_payload**
   - Для debugging
   - Для аудита
   - Для support запросов

3. **Использовать atomic transactions**
   - @transaction.atomic для всех операций с Subscription
   - Rollback при любых ошибках

### Subscription Logic:
1. **Один пользователь + один бот = одна активная подписка**
   - При оплате другого плана - продлеваем, не меняем plan
   - unique_together = ('user', 'plan', 'bot_id')

2. **Правильный расчёт expires_at**
   ```python
   anchor = max(current_expires_at, now) if current_expires_at else now
   new_expires_at = anchor + timedelta(days=duration_days)
   ```

3. **Всегда обнулять reminder счётчики при продлении**

### Security:
1. **Всегда проверять подпись в production**
   ```python
   if settings.WAYFORPAY_VERIFY_SIGNATURE:
       if not self.api.validate_response_signature(payload):
           return error
   ```

2. **Логировать все webhook**
   - До обработки
   - После обработки
   - При ошибках

3. **Валидировать валюту**
   ```python
   if payload.get('currency') != 'UAH':
       return error
   ```

### Logging:
1. **Структурированные логи**
   ```python
   logger.info(f"event=webhook_received user_id={user_id} order_ref={order_ref}")
   logger.info(f"event=subscription_extended sub_id={sub.id} new_expires={expires_at}")
   ```

2. **Логировать контекст при ошибках**
   ```python
   logger.exception(
       f"Failed to process webhook: bot_id={bot_id} user_id={user_id} "
       f"order_ref={order_ref} error={e}"
   )
   ```

---

## 📊 Monitoring & Alerts

### Key Metrics:
- **Invoice creation rate** (per hour)
- **Payment success rate** (APPROVED / total)
- **Webhook processing time** (p50, p95, p99)
- **Failed webhooks** (signature invalid, parsing errors)
- **Duplicate webhooks** (same orderReference)
- **Notification success rate**

### Alerts Setup:
```python
# payments/monitoring.py
def decline_stats(window_minutes=60, bot_id=None):
    """Статистика отказов за окно времени"""
    since = timezone.now() - timedelta(minutes=window_minutes)
    qs = Invoice.objects.filter(notified_at__gte=since)
    if bot_id:
        qs = qs.filter(bot_id=bot_id)
    
    total = qs.count()
    declined = qs.filter(payment_status=PaymentStatus.DECLINED).count()
    ratio = (declined / total) if total else 0.0
    
    return {"total": total, "declined": declined, "ratio": ratio}

def is_decline_rate_high(threshold=0.5, window_minutes=60, bot_id=None):
    """Превышен ли порог отказов"""
    stats = decline_stats(window_minutes, bot_id)
    return stats["ratio"] >= threshold
```

**Alert rules:**
- Decline rate > 50% за час → WARNING
- Webhook processing time > 2s → WARNING  
- Failed signature checks > 5 за час → CRITICAL
- No invoices created за 2 часа → INFO

---

## 🧪 Testing Strategy

### Unit Tests:
```python
# tests/payment/test_wayforpay_service.py
def test_create_invoice_generates_unique_order_reference():
    service = WayForPayService(bot_id=1)
    ref1 = Invoice.generate_order_reference(1, 123, 7)
    ref2 = Invoice.generate_order_reference(1, 123, 7)
    assert ref1 != ref2  # Разные из-за timestamp и random

def test_parse_order_reference_extracts_user_and_plan():
    api = WayForPayAPI()
    ref = "ORDER_1758606042kjI_407673079_7"
    user_id, plan_id, ts = api.parse_order_reference(ref)
    assert user_id == 407673079
    assert plan_id == 7
```

### Integration Tests:
```python
# tests/payment/test_webhook_basic.py
@pytest.mark.django_db
def test_webhook_approved_creates_subscription(client):
    user = TelegramUser.objects.create(user_id=123)
    plan = Plan.objects.create(bot_id=1, name="Test", price=10, duration_days=30)
    
    ref = Invoice.generate_order_reference(1, 123, plan.id)
    Invoice.objects.create(
        order_reference=ref,
        user=user,
        plan=plan,
        bot_id=1,
        amount=10,
        currency="UAH",
        payment_status=PaymentStatus.PENDING
    )
    
    payload = {
        "merchantAccount": "test",
        "orderReference": ref,
        "amount": 10,
        "currency": "UAH",
        "transactionStatus": "Approved",
        "reasonCode": "1100"
    }
    
    response = client.post("/api/payments/wayforpay/webhook/", json.dumps(payload))
    
    assert response.status_code == 200
    assert Subscription.objects.filter(user=user, bot_id=1).exists()
```

### E2E Tests:
```python
# tests/payment/test_full_flow.py
@pytest.mark.django_db
def test_full_payment_flow():
    # 1. Create invoice
    # 2. Mock WayForPay response
    # 3. Simulate webhook
    # 4. Assert subscription created
    # 5. Assert notification sent
    pass
```

---

## 🚀 Deployment Checklist

### Before Deploy:
- [ ] Все тесты проходят (pytest)
- [ ] Coverage > 80% для payment flow
- [ ] Code review пройден
- [ ] Миграции созданы и проверены
- [ ] Settings.py обновлён (WAYFORPAY_* variables)
- [ ] Секреты в .env файле (не в коде!)

### Deploy Steps:
```bash
# 1. Backup БД
python manage.py dumpdata > backup_$(date +%Y%m%d).json

# 2. Apply migrations
python manage.py migrate

# 3. Restart services
systemctl restart gunicorn
systemctl restart celery  # если используется
systemctl restart telegram-bot

# 4. Check logs
tail -f /var/log/django/error.log
tail -f /var/log/telegram-bot/bot.log
```

### After Deploy:
- [ ] Health check endpoint /api/health/ returns 200
- [ ] Test invoice creation в production
- [ ] Test webhook endpoint доступен
- [ ] Мониторинг показывает green status
- [ ] Test payment в staging environment

---

## 📚 Дополнительные ресурсы

### WayForPay Documentation:
- API Reference: https://wiki.wayforpay.com/
- Webhook Guide: https://wiki.wayforpay.com/view/852091
- Signature Algorithm: HMAC-MD5

### Django Best Practices:
- Database Transactions: https://docs.djangoproject.com/en/5.0/topics/db/transactions/
- Signals: https://docs.djangoproject.com/en/5.0/topics/signals/

### Testing:
- pytest-django: https://pytest-django.readthedocs.io/
- Factory Boy: https://factoryboy.readthedocs.io/

---

*Этот гайд - живой документ. Обновляется по мере развития проекта.*

*Последнее обновление: 2025-10-20*