Хорошо. Вот финальный **чек-лист по развёртыванию Django на FastPanel-хосте** (с нашим сценарием Gunicorn + Nginx + SSL + статика).

---

# 🚀 Гайд: Django на FastPanel с Gunicorn + Nginx

## 1. Подготовка окружения

```bash
export PROJECT_ROOT=/var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com
export DOMAIN=dev.astrocryptovoyager.com
export SERVICE=dev-astrovoyager
```

* Виртуальное окружение: `/opt/venvs/dev-astrovoyager/`
* Django проект: `$PROJECT_ROOT/profiling/`
* Gunicorn слушает: `127.0.0.1:8088`

---

## 2. Gunicorn (systemd-сервис)

Файл: `/etc/systemd/system/dev-astrovoyager.service`

```ini
[Unit]
Description=Gunicorn for dev.astrocryptovoyager.com (Django, Py3.12)
After=network.target

[Service]
User=devsvc
Group=devsvc
WorkingDirectory=/var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com
Environment="PATH=/opt/venvs/dev-astrovoyager/bin"
ExecStart=/opt/venvs/dev-astrovoyager/bin/gunicorn profiling.wsgi:application \
  --bind 127.0.0.1:8088 --workers 3 --timeout 60 --umask 007

[Install]
WantedBy=multi-user.target
```

Команды:

```bash
systemctl daemon-reload
systemctl enable --now dev-astrovoyager
systemctl status dev-astrovoyager
```

---

## 3. Nginx конфиг (FastPanel)

Файл: `/etc/nginx/fastpanel2-sites/astrocryptov_usr/dev.astrocryptovoyager.com.conf`

```nginx
upstream dev_upstream {
    server 127.0.0.1:8088;
}

server {
    server_name dev.astrocryptovoyager.com www.dev.astrocryptovoyager.com;

    listen 205.196.80.158:80;
    listen 205.196.80.158:443 ssl;

    ssl_certificate     /var/www/httpd-cert/dev.astrocryptovoyager.com_2025-09-07-16-50_18.crt;
    ssl_certificate_key /var/www/httpd-cert/dev.astrocryptovoyager.com_2025-09-07-16-50_18.key;

    set $root_path /var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com;
    root $root_path;

    # статика
    location ^~ /static/ {
        alias $root_path/staticfiles/;
        expires 30d;
    }

    # медиа
    location ^~ /media/ {
        alias $root_path/media/;
        expires 7d;
    }

    # django
    location / {
        proxy_pass http://dev_upstream;
        include /etc/nginx/proxy_params;
    }

    # healthcheck
    location /health/ {
        proxy_pass http://dev_upstream;
        access_log off;
    }

    error_log /var/www/astrocryptov_usr/data/logs/dev.astrocryptovoyager.com-frontend.error.log;
    access_log /var/www/astrocryptov_usr/data/logs/dev.astrocryptovoyager.com-frontend.access.log;
}
```

❗ Важно: отключить или закомментировать дефолтные server\_name `_` из `parking.conf` и `reuseport.conf`, иначе конфликты.

---

## 4. Django настройки (`settings.py`)

```python
ALLOWED_HOSTS = [
    "dev.astrocryptovoyager.com",
    "www.dev.astrocryptovoyager.com",
    "205.196.80.158",
    "localhost"
]
CSRF_TRUSTED_ORIGINS = ["https://dev.astrocryptovoyager.com"]

STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"
```

---

## 5. Статика и миграции

```bash
cd $PROJECT_ROOT
source /opt/venvs/dev-astrovoyager/bin/activate
python manage.py collectstatic --noinput
python manage.py migrate
python manage.py createsuperuser
```

---

## 6. Проверка

```bash
systemctl restart dev-astrovoyager
nginx -t && systemctl reload nginx
curl -I -H "Host: $DOMAIN" http://205.196.80.158/health/
```

Ожидаем:

```
HTTP/1.1 200 OK
Content-Type: application/json
```

---

✅ Теперь проект доступен по HTTPS, админка работает, статика/медиа обслуживаются, healthcheck возвращает `200`.

