18 - 10 - 2025
1. Понял! Давайте начнем с правок в Django файлах, а systemd сервис и venv определим позже.

## Правка 1: settings.py

**Файл:** `profiling/settings.py`

**Найти блок:**
```python
if os.getenv("DJANGO_ENV") == "production":
    STATIC_ROOT = '/var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com/staticfiles'
    MEDIA_ROOT = '/var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com/media'
```

**Заменить на:**
```python
if os.getenv("DJANGO_ENV") == "production":
    STATIC_ROOT = '/var/www/profiling/data/www/dev.profilinggroup.com/staticfiles'
    MEDIA_ROOT = '/var/www/profiling/data/www/dev.profilinggroup.com/media'
```

**И найти:**
```python
ALLOWED_HOSTS = [
    "dev.astrocryptovoyager.com",
    "www.dev.astrocryptovoyager.com",
    "205.196.80.158",
    "localhost"
]
```

**Заменить на:**
```python
ALLOWED_HOSTS = [
    "dev.profilinggroup.com",
    "www.dev.profilinggroup.com",
    "205.196.80.158",  # оставить старый IP или заменить на новый?
    "localhost"
]
```

2. Окружение

# Установим необходимые пакеты системы
apt-get update && apt-get install -y python3-venv python3-pip postgresql-client

# Создадим каталог для виртуальных окружений
mkdir -p /opt/venvs

# Создадим виртуальное окружение
python3 -m venv /opt/venvs/dev-profiling

# Активируем его
source /opt/venvs/dev-profiling/bin/activate

# Обновим pip
pip install --upgrade pip

# Установим зависимости
pip install -r requirements.txt

# Проверим что Django установлен
python manage.py check

