# 📋 ИНСТРУКЦИЯ: Создание нового бота (bot_N)

## На основе опыта с bot_2

---

## ✅ Шаг 1: Создать бота в Django админке

1. Откройте админку: `https://dev.astrocryptovoyager.com/admin/`
2. Перейдите в **Core → Bots → Add Bot**
3. Заполните поля:

```
bot_id: N (уникальное число)
title: Название бота (например, "Lead Bot")
username: username_bot (без @)
token: 1234567890:AAA... (токен от @BotFather)
is_enabled: ✓

port: 800N (уникальный порт, например 8003)
path: /var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com
log_path: /var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com/botlogs/bot_N
domain_name: dev.astrocryptovoyager.com
```

4. Нажмите **Save**

---

## ✅ Шаг 2: Создать конфиг Supervisor

```bash
sudo nano /etc/supervisor/conf.d/bot_N.conf
```

Вставьте (замените N на номер бота):

```ini
[program:bot_N]
command=/opt/venvs/dev-astrovoyager/bin/python /var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com/bot_runner_aiogram.py --bot-id N
directory=/var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com
autostart=true
autorestart=true
user=astrocryptov_usr
environment=DJANGO_SETTINGS_MODULE="profiling.settings"
stopsignal=TERM
stopwaitsecs=10 
stdout_logfile=/var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com/botlogs/bot_N.out.log
stdout_logfile_maxbytes=1MB 
stdout_logfile_backups=1 
stdout_logfile_owner=astrocryptov_usr:astrocryptov_usr
stderr_logfile=/var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com/botlogs/bot_N.err.log 
stderr_logfile_maxbytes=1MB 
stderr_logfile_backups=1 
stderr_logfile_owner=astrocryptov_usr:astrocryptov_usr
```

**ВАЖНО:** Строка `environment=DJANGO_SETTINGS_MODULE="profiling.settings"` обязательна!

Сохраните: `Ctrl+O`, `Enter`, `Ctrl+X`

---

## ✅ Шаг 3: Запустить бота

```bash
# Перечитать конфиги
sudo supervisorctl reread

# Добавить новый процесс
sudo supervisorctl add bot_N

# Проверить статус
sudo supervisorctl status
```

Ожидаемый результат: `bot_N  RUNNING  pid XXXXX, uptime 0:00:XX`

---

## 🧪 Шаг 4: Проверка

### 1. Проверить логи
```bash
tail -20 /var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com/botlogs/bot_N.out.log
```

Должно быть:
```
[PROD] Bot started: bot_id=N username=@... port=800N
```

### 2. Проверить порт
```bash
netstat -tlnp | grep 800N
```

### 3. Проверить webhook
```bash
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
```

Должно быть:
```json
{
  "ok": true,
  "result": {
    "url": "https://dev.astrocryptovoyager.com/tg/bot-N/webhook",
    "pending_update_count": 0
  }
}
```

### 4. Проверить в Telegram
- Откройте бота
- Отправьте `/start`
- Бот должен ответить

---

## 🔧 Устранение проблем

### Bot не запускается (BACKOFF/FATAL)

```bash
# Проверить ошибки
tail -50 /var/www/astrocryptov_usr/data/www/dev.astrocryptovoyager.com/botlogs/bot_N.err.log

# Типичные проблемы:
# - Порт уже занят → изменить port в админке и конфиге
# - Неверный токен → проверить token в админке
# - bot_id не существует → проверить в базе
```

### Webhook не работает

```bash
# Проверить nginx location
sudo nano /etc/nginx/sites-available/dev.astrocryptovoyager.com

# Должна быть секция:
location /tg/bot-N/webhook {
    proxy_pass http://127.0.0.1:800N/webhook;
    proxy_set_header Host $host;
}

# Перезагрузить nginx
sudo nginx -t
sudo systemctl reload nginx
```

---

## 📝 Чек-лист

- [ ] Бот создан в админке с правильным bot_id
- [ ] log_path содержит правильный номер (bot_N, не bot_1!)
- [ ] Конфиг supervisor создан в `/etc/supervisor/conf.d/bot_N.conf`
- [ ] Строка `environment=DJANGO_SETTINGS_MODULE="profiling.settings"` добавлена
- [ ] `supervisorctl reread` и `add` выполнены
- [ ] Статус = RUNNING
- [ ] Логи показывают успешный запуск
- [ ] Порт слушается
- [ ] Webhook установлен
- [ ] Бот отвечает в Telegram
- [ ] Nginx location настроен (если нужен)

---

## 🎯 Итого

Для создания нового бота нужно:
1. Создать запись в админке (3 мин)
2. Создать конфиг supervisor (2 мин)
3. Запустить через supervisorctl (1 мин)
4. Проверить работу (2 мин)

**Общее время: ~10 минут**

---

**Дата:** 2025-10-03  
**Проверено на:** bot_1, bot_2
