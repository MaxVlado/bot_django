вкратце: стягиваем ветку, обновляем `main`, вливаем изменения локально, пушим в `main`.

### Быстрый вариант (merge)

```bash
# 1) забрать всё с GitHub
git fetch origin

# 2) перейти на main и обновить его
git checkout main
git pull origin main

# 3) влить новую ветку в main (замени BRANCH на имя твоей ветки)
git merge --no-ff BRANCH -m "Merge BRANCH into main"

# если есть конфликты — реши их, затем:
git add -A
git commit    # если merge-коммит ещё не создан
# 4) пушим в удалённый main
git push origin main
```

### Альтернатива (чистая история через rebase перед merge)

```bash
git fetch origin
git checkout BRANCH
git pull --ff-only      # обновить свою ветку
git rebase origin/main  # «переписать» коммиты поверх свежего main

# решить конфликты, затем:
# git add <файлы>; git rebase --continue (повторять, пока не закончится)

# теперь быстрое слияние без лишнего merge-коммита
git checkout main
git pull origin main
git merge --ff-only BRANCH
git push origin main
```

### После (необязательно)

Удалить ветку, если больше не нужна:

```bash
git branch -d BRANCH
git push origin --delete BRANCH
```

### Примечания

* Если `main` защищён на GitHub (protected branch), прямой push может быть запрещён — тогда создай PR из `BRANCH` в `main`.
* Для “одним коммитом” можно сделать squash-пуш в main:

  ```bash
  git checkout main
  git pull origin main
  git merge --squash BRANCH
  git commit -m "feat: <краткое описание>"
  git push origin main
  ```
